//
//  MovieGridCell.swift
//  flixster
//
//  Created by Wildline  Lincifort on 9/15/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    
    @IBOutlet weak var posterView: UIImageView!
    
    
    
    
    
}
